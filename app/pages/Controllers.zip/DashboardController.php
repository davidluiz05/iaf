<?php

namespace App\Http\Controllers;

use App\Scholarship;

use Illuminate\Support\Facades\Config;

use App\Application;

use Illuminate\Support\Facades\DB;

use Carbon\Carbon;

use App\News;

use Illuminate\Support\Facades\Validator;

use App\Message;

use App\User;

use Illuminate\Http\Request;

use App\Http\Requests;

class DashboardController extends Controller
{
    public function getdashboard(Request $request){
    	$rules = array(
    		"user_id" => "required|numeric",
    		"date" => "required|date",
    		"type" => "required|numeric"
    	);
    	
    	$validator = Validator::make($request->all(), $rules);
    	if($validator->fails()){
    		return response()->json(array("status" => false, "error" => $validator->errors()->first()));
    	}
    	
    	$user_id = $request->input("user_id");
    	$date = $request->input("date");
    	$type = $request->input('type');
    	$user = User::find($user_id);
    	
    	
    	
    	$temp = array();
    	
    	//get messages count
    	$messages = Message::whereDate('updated_at', '>', $date)->where('receiver_id', '=', $user_id)->count();
    	$temp['messages'] = $messages;
    	
    	//get posts in week
    	$fromDate = Carbon::now()->subDay()->startOfWeek()->toDateString();
        $tillDate = Carbon::now()->subDay()->toDateString();             
        $news = News::whereBetween(DB::raw('date(updated_at)'),array($fromDate, $tillDate))->count();
        $temp['news'] = $news;
        
        
        
        if($type == Config::get('constants.USERTYPE.ADMIN')){
        	
        	//get pendding accounts
        	$accounts = User::where('status', '=', Config::get('constants.ACCOUNTSTATUS.PEDDING'))->count();
        	$temp['accounts'] = $accounts;
        
	        //get advertiser
	        $advertisers = User::where('type', '=', Config::get('constants.USERTYPE.ADVERTISER'))->count();
	        $temp['advertisers'] = $advertisers;
	        
	        //get applications
	        $applications = Application::where('status', '!=', Config::get('constants.APPLICATIONSTATUS.COMPLETE'))->count();
	        $temp['applications'] = $applications;
	        
	        //get schools
	        $schools = User::where('type', '=', Config::get('constants.USERTYPE.HIGHSCHOOL'))->orWhere('type', '=', Config::get('constants.USERTYPE.COLLEGE'))->whereDate('updated_at', '>', $date)->count();
	        $temp['schools'] = $schools;
        	
        }else if($type == Config::get('constants.USERTYPE.APPLICANT')){
        	
        	//get application count
        	$applications = Application::where('user_id', '=', $user_id)->where('status', '!=', Config::get('constants.APPLICATIONSTATUS.COMPLETE'))->count();
        	$temp['applications'] = $applications;
        	
        	$currentstate = $user->additionalData->location->state;
        	
        	//get near scholarship
	        $scholarships = Scholarship::with('college')->get();
	        $scholarships = $scholarships->reject(function($scholarship) use($currentstate){
	        	$college_state = $scholarship->college->location->state;
	        	if($college_state == $currentstate){
	        		return null;
	        	}else{
	        		return $scholarship;
	        	}
	        });
	        $temp['scholarships'] = count($scholarships);
	        
	        //get near schools
	        $schools = User::where('type', '=', Config::get('constants.USERTYPE.HIGHSCHOOL'))->orWhere('type', '=', Config::get('constants.USERTYPE.COLLEGE'))->whereDate('updated_at', '>', $date)->get();
			$nums = 0;
	        foreach($schools as $school){
				$school->additionalData->location;
				if($school->additionalData->location->state == $currentstate){
					$nums++;
				}
			}
	        $temp['schools'] = $nums;
        	
        }else if($type == Config::get('constants.USERTYPE.COLLEGE')){
        	//get application count
        	$nums = 0;
        	$college_id = $user->additionalData->id;
	        $applications = Application::with('Scholarship')->get()->toArray();
			foreach($applications as $application){
				if($application['scholarship']['college_id'] == $college_id){
					$nums++;
				}
			}
			$temp['applications'] = $nums; 

			$currentstate = $user->additionalData->location->state;
        	
        	//get near scholarship
	        $scholarships = Scholarship::with('college')->get();
	        $scholarships = $scholarships->reject(function($scholarship) use($currentstate){
	        	$college_state = $scholarship->college->location->state;
	        	if($college_state == $currentstate){
	        		return null;
	        	}else{
	        		return $scholarship;
	        	}
	        });
	        $temp['scholarships'] = count($scholarships);
	        
	        //get near schools
	        $schools = User::where('type', '=', Config::get('constants.USERTYPE.HIGHSCHOOL'))->orWhere('type', '=', Config::get('constants.USERTYPE.COLLEGE'))->whereDate('updated_at', '>', $date)->get();
			$nums = 0;
	        foreach($schools as $school){
				$school->additionalData->location;
				if($school->additionalData->location->state == $currentstate){
					$nums++;
				}
			}
	        $temp['schools'] = $nums;
        }else if($type == Config::get('constants.USERTYPE.HIGHSCHOOL')){
        	//get applications
        	$nums = 0;
        	$applications = Application::with('User')->get();
        	foreach($applications as $application){
        		$application->user->additionalData;
        		if($application->user->additionalData->school_id == $user->additionalData->id){
        			$nums++;
        		}
        	}  
        	$temp['applications'] = $nums;   

        	$currentstate = $user->additionalData->location->state;
        	
        	//get near scholarship
	        $scholarships = Scholarship::with('college')->get();
	        $scholarships = $scholarships->reject(function($scholarship) use($currentstate){
	        	$college_state = $scholarship->college->location->state;
	        	if($college_state == $currentstate){
	        		return null;
	        	}else{
	        		return $scholarship;
	        	}
	        });
	        $temp['scholarships'] = count($scholarships);
	        
	        //get near schools
	        $schools = User::where('type', '=', Config::get('constants.USERTYPE.HIGHSCHOOL'))->orWhere('type', '=', Config::get('constants.USERTYPE.COLLEGE'))->whereDate('updated_at', '>', $date)->get();
			$nums = 0;
	        foreach($schools as $school){
				$school->additionalData->location;
				if($school->additionalData->location->state == $currentstate){
					$nums++;
				}
			}
	        $temp['schools'] = $nums;
        }else if($type == Config::get('constants.USERTYPE.ADVERTISER')){
        	$currentstate = $user->additionalData->location->state;
        	
        	//get near scholarship
	        $scholarships = Scholarship::with('college')->get();
	        $scholarships = $scholarships->reject(function($scholarship) use($currentstate){
	        	$college_state = $scholarship->college->location->state;
	        	if($college_state == $currentstate){
	        		return null;
	        	}else{
	        		return $scholarship;
	        	}
	        });
	        $temp['scholarships'] = count($scholarships);
	        
	        //get near schools
	        $schools = User::where('type', '=', Config::get('constants.USERTYPE.HIGHSCHOOL'))->orWhere('type', '=', Config::get('constants.USERTYPE.COLLEGE'))->whereDate('updated_at', '>', $date)->get();
			$nums = 0;
	        foreach($schools as $school){
				$school->additionalData->location;
				if($school->additionalData->location->state == $currentstate){
					$nums++;
				}
			}
	        $temp['schools'] = $nums;
        	
        }else if($type == Config::get('constants.USERTYPE.DONOR')){
        	$currentstate = $user->additionalData->location->state;
        	
        	//get near scholarship
	        $scholarships = Scholarship::with('college')->get();
	        $scholarships = $scholarships->reject(function($scholarship) use($currentstate){
	        	$college_state = $scholarship->college->location->state;
	        	if($college_state == $currentstate){
	        		return null;
	        	}else{
	        		return $scholarship;
	        	}
	        });
	        $temp['scholarships'] = count($scholarships);
	        
	        //get near schools
	        $schools = User::where('type', '=', Config::get('constants.USERTYPE.HIGHSCHOOL'))->orWhere('type', '=', Config::get('constants.USERTYPE.COLLEGE'))->whereDate('updated_at', '>', $date)->get();
			$nums = 0;
	        foreach($schools as $school){
				$school->additionalData->location;
				if($school->additionalData->location->state == $currentstate){
					$nums++;
				}
			}
	        $temp['schools'] = $nums;
        }       
        
    	return response()->json(array("status" =>true, "data" => $temp));
	}
}
