<?php

namespace App\Http\Controllers;

use Anam\PhantomMagick\Converter;

use App\School;

use App\Location;

use App\Applicant;

use Illuminate\Support\Facades\Config;

use App\Application;

use App\Resource;

use App\Scholarship;

use Illuminate\Support\Facades\Validator;

use Illuminate\Http\Request;

use App\Http\Requests;

use App\User;

class ApplicationController extends Controller
{
    public function createapplication(Request $request){
    	$rules = array(
    		"id" => "required|numeric",
    		"scholarship_id" => "required|numeric",
    		"first_name" => "required|max:35|min:3",
    		"last_name" => "required|max:35|min:3",
    		"email" => "required|email|confirmed",
    		"address"=> "required",
    		"state" => "required",
    		"city"=> "required",
    		"phone" => "required|phone",
    		"zip" => "required",
    		"applicant_type" => "required|numeric",
    		"check_terms" => "required|boolean"
    	);
    	
    	$myrequest = array(
    		"id" => $request->input("id"),
    		"scholarship_id" => $request->input('scholarship_id'),
    		"first_name" => trim($request->input("first_name")),
    		"last_name" => trim($request->input("last_name")),
    		"email" => trim($request->input("email")),
    		"email_confirmation" => trim($request->input("email_confirmation")),
    		"address" => $request->input("address"),
    		"state" => $request->input("state"),
    		"city" => $request->input("city"),
    		"phone" => $request->input("phone"),
    		"zip" => $request->input("zip"),
    		"applicant_type" => $request->input("applicant_type"),
    		"check_terms" => $request->input("check_terms"),
    		"applicant_type" => $request->input("type")
    	);
    	
    	if($request->input("check_terms") == false){
    		return response()->json(array("status"=>false, "error"=>"please check Terms and Conditions"));
    	}
    	
    	$validator = Validator::make($myrequest, $rules);
    	if($validator->fails()){
    		return response()->json(array("status"=>false, "error"=>$validator->errors()->first()));
    	}
    	
    	
    	
    	//initialize application
    	$application = new Application();
    	$application->user_id = $request->input('id');
    	$application->scholarship_id = $request->input('scholarship_id');
    	$application->first_name = $request->input('first_name');
    	$application->last_name = $request->input('last_name');
    	if($request->has("middle_name")){
    		$application->middle_name = $request->input('middle_name');
    	}
    	$application->phone = $request->input("phone");
    	$application->email = $request->input("email");
    	if($request->input("applicant_type") == 0){
    		$application->status = Config::get('constants.APPLICATIONSTATUS.SENT');
    	}else{
    		$application->status = Config::get('constants.APPLICATIONSTATUS.PENDING');
    	}    	
    	
    	$location = new Location();
    	$location->address = $request->input("address");
    	$location->state = $request->input("state");
    	$location->city = $request->input("city");
    	$location->zip = $request->input("zip"); 	
    	
    	
    	$applicant_type = $request->input("applicant_type");
    	if($applicant_type == 0){
    		$rules = array(
    			"guidance_counselor" => "required",
    			"graduation_date_between" => "required|boolean"
    		);
    		
    		$validator = Validator::make($request->all(), $rules);
    		if($validator->fails()){
    			return response()->json(array("status"=>false, "error"=>$validator->errors()->first()));
    		}    		
    		
    		$location->save();
    		$application->location()->associate($location);    		
    		$application->guidance_counselor = $request->input("guidance_counselor");
    		$application->graduation_date_between = $request->input("graduation_date_between");
    		$application->save();   		
    		
    	}else if($applicant_type == 1){
    		$rules = array("is_over" => "required|boolean");
    		$validator = Validator::make($request->all(), $rules);
    		if($validator->fails()){
    			return response()->json(array("status"=>false, "error"=>$validator->errors()->first()));
    		}  
    		
    		$location->save();
    		$application->location()->associate($location);
    		$application->is_over = $request->input("is_over");
    		$application->save();  		
    		
    	}else if($applicant_type == 2){
    		$rules = array(
    			"service_branch" => "required",
    			"military_status" => "required",
    			"discharge_date" => "required|date"
    		);
    		$validator = Validator::make($request->all(), $rules);
    		if($validator->fails()){
    			return response()->json(array("status"=>false,"error"=>$validator->errors()->first()));
    		}   

    		$location->save();
    		$application->location()->associate($location);
    		$application->service_branch = $request->input("service_branch");
    		$application->military_status = $request->input("military_status");
    		$application->discharge_date = $request->input("discharge_date");
    		$application->save();     		
    	}
    	
    	return response()->json(array("status"=>true));
	}
	
	public function getapplicationsbyuser(Request $request){
		$rules = array(
			"user_id" => "required|numeric"
		);
		
		$validator = Validator::make($request->all(), $rules);
		if($validator->fails()){
			return response()->json(array("status"=>false, "error"=>$validator->fails()->error));
		}
		
		$applications = Application::with('Scholarship')->where(array(
			"user_id" => $request->input("user_id")
		))->get()->toArray();
		$temp = array();
		foreach($applications as $application){
			$application['college'] = School::find($application['scholarship']['college_id']);
			$temp[] =$application; 
		}
		
		return response()->json(array("status"=>true, "applications"=> $temp));
	}
	
	public function getapplicationsbycollege(Request $request){
		$rules = array(
			"college_id" => "required|numeric"
		);
		
		$validator = Validator::make($request->all(), $rules);
		if($validator->fails()){
			return response()->json(array("status"=>false, "error"=>$validator->errors()->first()));
		}
		
		$college_id = $request->input('college_id');		
		$temp = array();
		$applications = Application::with('Scholarship')->get()->toArray();
		foreach($applications as $application){
			if($application['scholarship']['college_id'] == $college_id){
				$temp[] = $application;
			}
		}
		
		return response()->json(array("status"=>true, "applications"=> $temp));
	}
	
	public function getapplicationsbyschool(Request $request){
		$rules = array(
			"school_id" => "required|numeric"
		);
		$validator = Validator::make($request->all(), $rules);
		if($validator->fails()){
			return response()->json(array("status" => false, "error" => $validator->errors()->first()));
		}
		
		$applications = Application::with(array("User", "Scholarship"))->get();
		$applications = $applications->transform(function($application){
			$application->user->additionalData;
			return $application;
		});
		$temp = array();
		$applications = $applications->toArray();		
		foreach($applications as $application){
			if($application['user']['type'] == Config::get('constants.USERTYPE.APPLICANT') && $application['user']['additional_data']['applicant_type'] == 0 && $application['user']['additional_data']['school_id'] == $request->input("school_id")){
				$temp[] = $application;
			}
		}
		
		return response()->json(array("status" => true, "applications" => $temp));
	}
	
	public function getapplications(Request $request){
		$applications = Application::with('Scholarship')->get()->toArray();
		$temp = array();
		foreach($applications as $application){
			$application['college'] = School::find($application['scholarship']['college_id']);
			$temp[] =$application; 
		}
		
		return response()->json(array("status"=>true, "applications"=> $temp));
	}
	
	public function accept(Request $request){
		$rules = array(
			"id" => "required|numeric",
			"type" => "required|numeric"
		);
		
		$validator = Validator::make($request->all(), $rules);
		if($validator->fails()){
			return response()->json(array("status"=> false, "error"=>$validator->errors()->first()));
		}
		
		$application = Application::find($request->input('id'));
		if(!$application){
			return response()->json(array("status" => false, "error"=>"Cannot find specific application"));
		}
		
		if($request->input('type') == Config::get('constants.USERTYPE.HIGHSCHOOL')){
			$application->status = Config::get('constants.APPLICATIONSTATUS.PENDING');
		}else{
			$application->status = Config::get('constants.APPLICATIONSTATUS.ACCEPTED');
			
			//create certificate and awardletter
			$first_name = $application->user->first_name;
			$last_name = $application->user->last_name;
			$address = $application->user->additionalData->location->address;
			$city = $application->user->additionalData->location->city;
			$state = $application->user->additionalData->location->state;
			$zip = $application->user->additionalData->location->zip;			
			$college_name = $application->scholarship->college->name;
			$college_state = $application->scholarship->college->location->state;
			$college_city = $application->scholarship->college->location->city;
			$type = $application->scholarship->availabelto;
			$date = date("Y-m-d");
			
			$cfilename = "certificate_".$application->user->id."_".$date.".png";
			$conv = new Converter();
			$conv->source(url("png/viewcertificate?name=".$first_name." ".$last_name."&type=".$type."&date=".$date))
				 ->setBinary(public_path().'/phantomjs-2.1.1-windows/bin/phantomjs.exe')
				 ->toPng(array(
				 	"width" => 900,
				 	"height" => 850
				 ))
				 ->save(public_path('img/certificate/'.$cfilename));
				 
			$afilename = "award_".$application->user->id."_".$date.".png";
			$conv = new Converter();
			$conv->source(url("png/viewaward?first_name=".$first_name."&last_name=".$last_name."&address=".$address."&city=".$city."&state=".$state."&zip=".$zip."&college_name=".$college_name."&college_city=".$college_city."&college_state=".$college_state))
				 ->setBinary(public_path().'/phantomjs-2.1.1-windows/bin/phantomjs.exe')
				 ->toPng(array(
				 	"width" => 500,
				 	"height" => 900
				 ))
				 ->save(public_path('img/award/'.$afilename));
			$application->certificate_url = url('img/certificate/'.$cfilename);
			$application->award_url = url('img/award/'.$afilename);
			$application->save();
			
		}
		
		$application->save();
		return response()->json(array("status"=> true));
	}
	
	public function reject(Request $request){
		$rules = array(
			"id" => "required|numeric"
		);
		
		$validator = Validator::make($request->all(), $rules);
		if($validator->fails()){
			return response()->json(array("status"=> false, "error"=>$validator->errors()->first()));
		}
		
		$application = Application::find($request->input('id'));
		if(!$application){
			return response()->json(array("status" => false, "error"=>"Cannot find specific application"));
		}
		
		$application->status = Config::get('constants.APPLICATIONSTATUS.REJECTED');
		$application->save();
		return response()->json(array("status"=> true));
	}
	
	public function test(){
		$conv = new Converter();
		$conv->source("http://192.168.3.228/IAF/public/pdf/viewaward")
			 ->setBinary(public_path().'/phantomjs-2.1.1-windows/bin/phantomjs.exe')
			 ->toPng(array(
			 	"width" => 960,
			 	"height" => 850
			 ))
			 ->save(public_path().'/img/1.png');
	}
}
