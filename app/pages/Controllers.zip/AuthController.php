<?php

namespace App\Http\Controllers;

use App\Http\Requests\APIRequest;

use Illuminate\Support\Facades\Config;

use Illuminate\Validation\validate;

use Illuminate\Auth\Access\Response;

use App\ResetPass;

use Illuminate\Support\Facades\Mail;

use App\Company;

use Illuminate\Support\Facades\Validator;

use App\School;

use App\Applicant;

use Carbon\CarbonInterval;

use App\Carbon;

use App\User;

use App\Location;

use Illuminate\Http\Request;

use App\Http\Requests;

class AuthController extends Controller
{
    public function register(Request $request){
    	$rules = array(
    		"type"=> "required|numeric"
    	);
    	
    	$validator = Validator::make($request->all(), $rules);
    	If($validator->fails()){
    		return response()->json(array("status"=> false, "error"=> $validator->errors()->first()));
    	}
    	if($request->input('check_terms') == 'false'){
    		return response()->json(array("status"=>false,"error"=>"Please accept Terms and Conditions"));	
    	}
    	
    	$type = $request->input("type");
    	if($type == Config::get('constants.USERTYPE.APPLICANT')){ // user is applicant
    		$myrequests = array(
    			"applicant_type" => $request->input('applicant_type'),
    			"first_name" => trim($request->input('first_name')),
    			"last_name" => trim($request->input('last_name')),
    			"email" => trim($request->input('email')),
    			"address" => trim($request->input('address')),
    			"city" => trim ($request->input('city')),
    			"state" => trim($request->input('state')),    			
    			"password" => $request->input("password"),
    			"onesignal_code" => $request->input("onesignal_code"),
    			"email_confirmation" => trim($request->input('email_confirmation')),
    			"password_confirmation" => $request->input('password_confirmation'),
    			"zip" => trim($request->input('zip'))
    		);
    		
    		$rules = array(
    			"applicant_type"=> "required|numeric",
    			"first_name"=> "required|max:35|min:2",
    			"last_name"=> "required|max:35|min:2",
    			"email"=> "required|email|unique:users|confirmed",
    			"address"=> "required",
    			"city"=> "required",
    			"state"=> "required",
    			"zip"=> "required",    			
    			"password"=> "required|min:8|confirmed",
    			"onesignal_code" => "required"    					
    		);
    		
    		$validator = Validator::make($myrequests, $rules);
    		if($validator->fails()){
    			return response()->json(array("status"=> false, "error"=> $validator->errors()->first()));
    		}
    		
    		//create applicant
    		$applicant = new Applicant();
    		$applicant->applicant_type = $request->input('applicant_type');
    		$applicant->save();
    		
    		//create user
    		$user = new User();
    		$user->first_name = $request->input('first_name');
    		$user->last_name = $request->input('last_name');
    		if($request->has('middle_name')){
    			$user->middle_name = $request->input('middle_name');
    		}    		
    		$user->email = $request->input('email');
    		$user->password = md5($request->input('password'));
    		$user->type = $type;
    		$user->status = Config::get('constants.ACCOUNTSTATUS.ACTIVE');
    		$user->save();
    		
    		//create location
    		$location = new Location();
    		$location->address = $request->input('address');
    		$location->city = $request->input('city');
    		$location->state = $request->input('state');
    		$location->zip = $request->input('zip');
    		$location->save();
    		
    		//create relationship
    		$user->additionalData()->save($applicant);
    		$user->save();
    		
    		//create relationship
    		$applicant->location()->associate($location);
    		$applicant->save();
    		
    		//save onesignal id
    		$user->onesignal_code = $request->input('onesignal_code');
    		$user->save();   		
    		
    		return response()->json(array("status"=> true, "id"=> $user->id, "full_name"=>$user->first_name." ".$user->last_name,"profile_img" => $user->profile_img, "type"=>$user->type, "applicant_type"=>$applicant->applicant_type));
    	}else if($type == Config::get('constants.USERTYPE.COLLEGE') || $type == Config::get('constants.USERTYPE.HIGHSCHOOL')){ //user is college or  high school
    		$myrequests = array(
    			"school_name" => trim($request->input('school_name')),
    			"first_name" => trim($request->input('first_name')),
    			"last_name" => trim($request->input('last_name')),
    			"email" => trim($request->input('email')),
    			"address" => trim($request->input('address')),
    			"city" => trim ($request->input('city')),
    			"state" => trim($request->input('state')),    			
    			"password" => $request->input("password"),
    			"onesignal_code" => $request->input("onesignal_code"),
    			"job_title" => trim($request->input("job_title")),
    			"email_confirmation" => trim($request->input('email_confirmation')),
    			"password_confirmation" => $request->input('password_confirmation'),
    			"zip" => trim($request->input('zip')),
    			"phone" => $request->input("phone")
    		);
    		
    		$rules = array(
    			"school_name"=> "required",    			
    			"first_name"=> "required|min:2|max:35",
    			"last_name"=> "required|min:2|max:35",    			
    			"email"=> "required|email|unique:users|confirmed",
    			"password"=> "required|min:8|confirmed",
    			"job_title"=> "required",
    			"address"=> "required",
    			"city"=> "required",
    			"state"=> "required",
    			"zip"=> "required",
    			"onesignal_code"=>"required",
    			"phone" => "required|phone"
    		);
    		
    		$validator = Validator::make($myrequests, $rules);
    		if($validator->fails()){
    			return response()->json(array("status"=> false, "error"=> $validator->errors()->first()));
    		}
    		
    		//create user 
    		$user = new User();
    		$user->first_name = $request->input('first_name');
    		$user->last_name = $request->input('last_name');
    		if($request->has('middle_name')){
    			$user->middle_name = $request->input('middle_name');
    		}    		
    		$user->email = $request->input('email');
    		$user->password = md5($request->input('password'));
    		$user->type = $type;
    		$user->status = Config::get('constants.ACCOUNTSTATUS.PEDDING');
    		$user->phone = $request->input("phone");
    		$user->save();
    		
    		//create Location
    		$location = new Location();
    		$location->address = $request->input('address');
    		$location->city = $request->input('city');
    		$location->state = $request->input('state');
    		$location->zip = $request->input('zip');
    		$location->save();
    		
    		//create school
    		$school = new School();
    		$school->name = $request->input('school_name');
    		$school->job_title = $request->input('job_title');
    		$school->type = ($type == Config::get('constants.USERTYPE.COLLEGE'))?Config::get('constants.SCHOOLTYPE.COLLEGE'): Config::get('constants.SCHOOLTYPE.HIGHSCHOOL');
    		$school->save();
    		
    		//create relationship
    		$user->additionalData()->save($school);
    		$user->save();
    		
    		$school->location()->associate($location);
    		$school->save();
    		
    		//save onesignal code
    		$user->onesignal_code = $request->input('onesignal_code');
    		$user->save();
    		
    		return response()->json(array("status"=> true, "id"=> $user->id, "full_name"=>$user->first_name." ".$user->last_name,"profile_img" => $user->profile_img, "type"=>$user->type, "college_id" => $school->id));    		    		
    	}else if($type == Config::get('constants.USERTYPE.ADVERTISER') || $type == Config::get('constants.USERTYPE.DONOR')){ //user is Advertiser or Donor
    		$myrequests = array(    			
    			"first_name" => trim($request->input('first_name')),
    			"last_name" => trim($request->input('last_name')),
    			"email" => trim($request->input('email')),
    			"address" => trim($request->input('address')),
    			"city" => trim ($request->input('city')),
    			"state" => trim($request->input('state')),    			
    			"password" => $request->input("password"),
    			"onesignal_code" => $request->input("onesignal_code"),
    			"company_name" => trim($request->input("company_name")),
    			"email_confirmation" => trim($request->input('email_confirmation')),
    			"password_confirmation" => $request->input('password_confirmation'),
    			"zip" => trim($request->input('zip')),
    			"phone" => $request->input("phone")
    		);
    		
    		$rules = array(
				"first_name"=> "required|min:2|max:35",
    			"last_name"=> "required|min:2|max:35",
    			"email"=> "required|email|unique:users|confirmed",
    			"password"=> "required|min:8|confirmed",    					
    			"company_name"=> "required",
    			"address"=> "required",
    			"city"=> "required",
    			"state"=> "required",
    			"zip"=> "required",
    			"phone" => "required|phone"    			    		
    		);
    		$validator = Validator::make($myrequests, $rules);
    		if($validator->fails()){
    			return response()->json(array("status"=> false, "error"=> $validator->errors()->first()));
    		}
    		
    		//create user
    		$user = new User();
    		$user->first_name = $request->input('first_name');
    		$user->last_name = $request->input('last_name');
    		if($request->has('middle_name')){
    			$user->middle_name = $request->input('middle_name');
    		}    		
    		$user->email = $request->input('email');
    		$user->password = md5($request->input('password'));
    		$user->type = $type;
    		$user->phone = $request->input("phone");
    		$user->status = Config::get('constants.ACCOUNTSTATUS.PEDDING');
    		$user->save();
    		
    		//create company
    		$company = new Company();    		
    		$company->name = $request->input('company_name');
  			$company->save();
  			
  			//create location
  			$location = new Location();
  			$location->address = $request->input('address');
  			$location->city = $request->input('city');
  			$location->state = $request->input('state');
  			$location->zip = $request->input('zip');
  			$location->save();
  			
  			
			//create relationship
			$company->location()->associate($location);
			$company->save();
			
			$user->additionalData()->save($company);
			$user->save(); 
			
			//save onesignal code
			$user->onesignal_code = $request->input('onesignal_code');
			$user->save();

			return response()->json(array("status"=> true, "id"=> $user->id, "full_name"=>$user->first_name." ".$user->last_name,"profile_img" => $user->profile_img, "type" => $user->type));
    	}
	}
	
	public function login(Request $request){
		$rules = array(
			"email"=> "required|email",
			"password"=> "required",
			"onesignal_code"=>"required"
		);
		
		$validator = Validator::make(array(
										'email' => trim($request->input('email')),
										'password' => $request->input('password'),
										'onesignal_code' => $request->input('onesignal_code')
										), $rules);
		if($validator->fails()){
			return response()->json(array("status"=> false, "error"=> $validator->errors()->first()));
		}
		
		$user = User::where(array("email"=> $request->input("email"), "password"=> md5($request->input("password"))))->get()->first();
		if(!$user){
			return response()->json(array("status"=> false, "error"=> "don't match email/password"));
		}else{
			if($user->status == Config::get('constants.ACCOUNTSTATUS.DELETED')){
				return response()->json(array("status"=> false, "error"=> "Your account already deleted."));
			}else{
				$user->onesignal_code = $request->input("onesignal_code");
				$user->save();
				
				if($user->type == Config::get('constants.USERTYPE.APPLICANT')){
					$user->additionalData;
					return response()->json(array("status"=> true, "id"=> $user->id, "full_name"=>$user->first_name ." ". $user->last_name, "profile_image"=> $user->profile_image, "type"=> $user->type, "applicant_type" => $user->additionalData->applicant_type));
				}else if($user->type == Config::get('constants.USERTYPE.COLLEGE') || $user->type == Config::get('constants.USERTYPE.HIGHSCHOOL')){
					$user->additionalData;
					return response()->json(array("status"=> true, "id"=> $user->id, "full_name"=>$user->first_name ." ". $user->last_name, "profile_image"=> $user->profile_image, "type"=> $user->type, "college_id" => $user->additionalData->id));
				}else{
					return response()->json(array("status"=> true, "id"=> $user->id, "full_name"=>$user->first_name ." ". $user->last_name, "profile_image"=> $user->profile_image, "type"=> $user->type));
				}				
			}			
		}
	}
	
	public function sendcode(Request $request){
		$rules = array(
			"email" => "required|email"
		);
		
		$validator = Validator::make($request->all(), $rules);
		if($validator->fails()){
			return response()->json(array("status" => false, "error" => $validator->errors()->first()));
		}
		$code = rand(10000, 99999);
		$user = User::where(array("email" => $request->input("email")))->get()->first();
		if($user){
			Mail::send('emails.sendcode', array('user' => $user ,'code' => $code), function($m) use ($user) {
				$m->from('john.cruyf820@gmail.com', 'IAF');
				$m->to($user->email, $user->first_name. " ".$user->last_name)->subject('Verify Code');
			});
			
			$record = new ResetPass();
			$record->email = $user->email;
			$record->code = $code;
			$record->save();
		}
		return response()->json(array("status"=> true));
	}
	
	public function checkcode(Request $request){
		$rules = array(
			"email" => "required|email",
			"code"=>"required|numeric"
		);
		
		$validator = Validator::make($request->all(), $rules);
		if ($validator->fails()){
			return response()->json(array("status"=> false, "error"=>$validator->errors()->first()));
		}
		
		$record = ResetPass::where(array("email"=> $request->input('email'), "code" => $request->input('code')))->get()->first();
		if($record){
			return Response()->json(array("status"=> true));
		}else{
			return response()->json(array("status"=> false, "error"=>"dont't match code"));
		}
	}
	
	public function resetpassword(Request $request){
		$rules = array(
			"email"=> "required|email",
			"password"=> "required|min:8|confirmed"			
		);
		
		$validator = validator::make($request->all(), $rules);
		if($validator->fails()){
			return response()->json(array("status"=>false, "error"=>$validator->errors()->first()));
		}
		
		$user = User::where(array("email" => $request->input('email')))->get()->first();
		$user->password = md5($request->input('password'));
		$user->save();
		return response()->json(array("status"=>true));
	}	
}
